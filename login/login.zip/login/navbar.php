<nav class="navbar">
    <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="dashboard.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="contactus.php">Contact Us</a></li>
        <li class="nav-item"><a class="nav-link" href="projects.php">Projects</a></li>
        <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
        <h3 style="color: blue; text-align: center;">Welcome, <?php echo $name; ?>!</h3>
    </ul>
</nav>