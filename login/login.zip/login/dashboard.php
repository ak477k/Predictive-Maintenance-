<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (empty($_SESSION['uid'])) {
    header('location: logout.php');
} else {
    $uid = $_SESSION['uid'];
    $query = "SELECT FullName FROM tbluser WHERE ID = '$uid'";
    $result = mysqli_query($con, $query);
    if ($result) {
        $row = mysqli_fetch_array($result);
        $name = $row['FullName'];
    } else {
        // Handle database query error here
        $name = "Unknown User";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Welcome Page</title>
    <style>
        /* Body and Page Styles */
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .page-wrapper {
            background-color: #fff;
            margin: 20px auto;
            max-width: 800px;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        /* Navigation Bar Styles */
        .navbar {
            background-color: lightblue;
            overflow: hidden;
            color:black;
        }

        .navbar ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }

        .navbar li {
            float: left;
        }

        .navbar li a {
            display: block;
            color: black;
            font-weight: bold;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        .navbar li a:hover {
            background-color: #555;
        }

        /* Card Styles */
        .card {
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-top: 20px;
        }

        /* Welcome Message Styles */
        .welcome-message {
            color: #333;
            font-size: 24px;
            text-align: center;
        }

        /* Logout Button Styles */
        .btn-logout {
            display: block;
            margin-top: 20px;
            text-align: center;
        }
        /* .content {
            color: #333;
            font-size: 16px;
            margin-top: 20px;
        } */
        .content {
                color: black;
                font-size: 16px;
                /* margin-top: 10px; */
                background-color: #f2f2f2; /* Background color */
                padding: 20px; /* Add some padding for better readability */
            }
        /* Style the headings and paragraphs within the content */
        .content h2 {
            font-size: 20px;
            font-weight: bold;
            margin-top: 10px;
        }

        .content p {
            margin-bottom: 10px;
        }


    </style>

</head>

<body>
    <div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo">
        <div class="wrapper wrapper--w680">
            <!-- <nav class="navbar">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="contactus.php">Contact Us</a></li>
                    <li class="nav-item"><a class="nav-link" href="projects.php">Projects</a></li>
                    <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
                    <h3 style="color: blue; text-align: center;">Welcome, <?php echo $name; ?>!</h3>
                </ul>
            </nav> -->
            <?php include('navbar.php'); ?>
            <div class="card card-1">
                <div class="card-body">
                <div class="content">
                <h2>Waste Management</h2>
    <p>
        Waste (or wastes) are unwanted or unusable materials. Waste is any substance discarded after primary use, or is worthless, defective and of no use. A by-product, by contrast is a joint product of relatively minor economic value. A waste product may become a by-product, joint product or resource through an invention that raises a waste product's value above zero.
    </p>
    <p>
        Examples include municipal solid waste (household trash/refuse), hazardous waste, wastewater (such as sewage, which contains bodily wastes (feces and urine) and surface runoff), radioactive waste, and others.
    </p>
    <!-- Add an image from Google here -->
    <img src="waste.jpg" alt="Waste Image" style="width: 400px; height: 300px;">
    <h2>Types of Waste</h2>
    <ul>
        <li>Municipal waste</li>
        <li>Household waste and commercial waste</li>
        <li>Construction and demolition waste</li>
    </ul>
    <h2>The 3Rs – Reuse, Reduce, Recycle</h2>
    <p>
        Reduce - try to reduce the use of single-use products, especially plastic substances.
    </p>
    <p>
        Reuse - always try to reuse day-to-day things. For example, carry a kit when you are going for shopping.
    </p>
    <p>
        Recycle - try maximum to recycle or reuse things other than disposing of.
    </p>
    <p>
        Above all 3R’s will help us and our society for the proper disposal of waste management.
    </p>
    <!-- Add another image from Google here -->
    <img src="3R.jpg" alt="Recycle Image" style="width: 400px; height: 300px;">
    <h2>Efforts in Waste Management</h2>
    <p>
        In a bid to raise awareness regarding effective disposal of waste, students of the Department of Communicative English visited a total of 329 houses in Mulavukad Grama Panchayat. They shared knowledge and strategies on proper waste management. With the help of Google Forms, the present methods of waste disposal were studied, and the concept of bucket composting was introduced. A report based on the survey was later submitted to the Panchayat President.
    </p>
                    </div>
                  <!-- body -->
                </div>
            </div>
        </div>
    </div>

    <!-- Your JavaScript and other body content go here -->
</body>

</html>
